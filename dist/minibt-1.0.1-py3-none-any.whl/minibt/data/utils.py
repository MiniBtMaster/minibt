from .tools import *


class LocalDatas(base):
    """本地CSV数据"""
    pp2509_60 = DataString("pp2509_60")
    test = DataString("test")
    v2509 = DataString("v2509")
    v2509_1 = DataString("v2509_1")
    v2509_1h = DataString("v2509_1h")
    v2509_60 = DataString("v2509_60")
    v2509_60_1 = DataString("v2509_60_1")
    v2509_60_2 = DataString("v2509_60_2")
    v2509_60_3 = DataString("v2509_60_3")


LocalDatas=LocalDatas()